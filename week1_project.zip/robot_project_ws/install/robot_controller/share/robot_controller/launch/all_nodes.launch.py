from launch import LaunchDescription                 # Import LaunchDescription to define a launch file
from launch_ros.actions import Node                  # Import Node to launch ROS 2 nodes

# Function that generates and returns the launch description for multiple nodes
def generate_launch_description():

    # Path to the configuration file containing ROS 2 parameters (YAML format)
    config_path = '/home/omar/robot_project_ws/src/robot_controller/config/params.yaml'

    # Return a LaunchDescription object that defines the nodes to be launched
    return LaunchDescription([
        # Launch the Status Publisher node
        Node(
            package='robot_controller',              # Package name where the node is located
            executable='status_publisher',           # Executable name defined in setup.py entry points
            name='status_publisher',                 # Node name in the ROS 2 graph
            parameters=[config_path]                 # Load parameters from the YAML config file
        ),
        # Launch the Velocity Publisher node
        Node(
            package='robot_controller',              # Same package
            executable='velocity_publisher',         # Executable name
            name='velocity_publisher',               # Node name
            parameters=[config_path]                 # Load parameters
        ),
        # Launch the Command Subscriber node
        Node(
            package='robot_controller',              # Same package
            executable='command_subscriber',         # Executable name
            name='command_subscriber'                # Node name
            # No parameters file specified for this node
        )
    ])
