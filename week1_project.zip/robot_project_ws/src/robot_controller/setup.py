import os                                      # Import the OS module for file path operations
from glob import glob                          # Import glob to match file patterns (e.g., launch/*.py)
from setuptools import find_packages, setup    # Import setup tools to configure and install the ROS 2 package

# Define the package name for the ROS 2 Python node package
package_name = 'robot_controller'

# Setup configuration for building and installing the ROS 2 package
setup(
    name=package_name,                         # Name of the package
    version='0.0.0',                           # Initial version of the package
    packages=find_packages(exclude=['test']),  # Automatically find sub-packages, excluding the 'test' folder
    data_files=[
        # Register the package in the ament index (used by ROS 2 to find packages)
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),

        # Include the package.xml file (contains metadata about the package)
        ('share/' + package_name, ['package.xml']),

        # Include all launch files from the 'launch' directory
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools'],           # Dependencies required for installation
    zip_safe=True,                             # Whether the package can be safely zipped
    maintainer='omar',                         # Maintainer's name
    maintainer_email='omar@todo.todo',         # Maintainer's contact email
    description='TODO: Package description',   # Short description of the package
    license='TODO: License declaration',       # License type (to be specified later)
    extras_require={
        'test': [                              # Extra dependencies for running tests
            'pytest',
        ],
    },
    entry_points={                             # Define executable ROS 2 nodes (console scripts)
        'console_scripts': [
            # Each entry maps a command name to a Python function
            'status_publisher = robot_controller.status_publisher:main',
            'velocity_publisher = robot_controller.velocity_publisher:main',
            'command_subscriber = robot_controller.command_subscriber:main',
        ],
    },
)
