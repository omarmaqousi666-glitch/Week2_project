
import pytest                                         # Import the pytest framework for testing
import rclpy                                          # Import the ROS 2 Python client library
from robot_controller.status_publisher import StatusPublisher   # Import the StatusPublisher node to test

# Define a pytest fixture that sets up and tears down the ROS 2 node
@pytest.fixture
def node():
    rclpy.init()                                      # Initialize the ROS 2 system
    node = StatusPublisher()                          # Create an instance of the StatusPublisher node
    yield node                                        # Provide the node to the test functions
    node.destroy_node()                               # Destroy the node after tests complete
    rclpy.shutdown()                                  # Shutdown ROS 2 cleanly

# Test to verify that the timer_period parameter is correctly set and positive
def test_timer_period_parameter(node):
    period = node.get_parameter('timer_period').value  # Retrieve the 'timer_period' parameter value
    assert period > 0.0, "Timer period must be positive"  # Ensure the period is greater than zero

# Test to verify that the publisher was created successfully
def test_publisher_exists(node):
    assert node.publisher_ is not None, "Publisher should be created"  # Ensure publisher_ exists
