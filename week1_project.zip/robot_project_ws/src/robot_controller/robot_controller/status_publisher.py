import rclpy                               # Import the ROS 2 Python client library
from rclpy.node import Node                # Import the Node base class for creating ROS 2 nodes
from std_msgs.msg import String            # Import the standard String message type

# Define a node class that publishes robot status and subscribes to robot commands
class StatusPublisher(Node):
    def __init__(self):
        super().__init__('status_publisher')   # Initialize the node with the name 'status_publisher'

        # Declare a ROS 2 parameter for the timer period (default = 2 seconds)
        self.declare_parameter('timer_period', 2)
        timer_period = self.get_parameter('timer_period').value  # Get the parameter value

        # Create a publisher to send status messages on the '/robot/status' topic
        self.publisher_ = self.create_publisher(String, '/robot/status', 10)

        # Create a subscriber to listen for commands on the '/robot/command' topic
        self.subscriber_ = self.create_subscription(
            String,                           # Message type
            '/robot/command',                 # Topic name
            self.command_callback,            # Callback function for incoming messages
            10                                # Queue size
        )

        # Initialize a status message with a default value
        self.status_msg = String()
        self.status_msg.data = "Robot is ready"
        
        # Create a timer that triggers the 'publish_status' method every 'timer_period' seconds
        self.timer_ = self.create_timer(timer_period, self.publish_status)
        
        # Log that the node has started and show the timer value
        self.get_logger().info(f'Status Publisher started with timer = {self.timer_}s')

    # Function that publishes the current robot status periodically
    def publish_status(self):
        try:
            self.publisher_.publish(self.status_msg)   # Publish the status message
            self.get_logger().info(f'Published: "{self.status_msg.data}"')  # Log the published message
        except Exception as e:
            # Log any errors that occur during publishing
            self.get_logger().error(f'Failed to publish status: {e}')

    # Callback function executed whenever a command message is received
    def command_callback(self, msg):
        # Update the status message based on the received command
        if msg.data.lower() == 'start':
            self.status_msg.data = 'Robot started'
        elif msg.data.lower() == 'stop':
            self.status_msg.data = 'Robot stopped'
        elif msg.data.lower() == 'reset':
            self.status_msg.data = 'Robot is ready'
        else:
            # Warn if the received command is not recognized
            self.get_logger().warn(f'Unknown command: "{self.status_msg.data}"')


# Main function that initializes and runs the node
def main(args=None):
    rclpy.init(args=args)                 # Initialize the ROS 2 Python library
    node = StatusPublisher()              # Create an instance of the StatusPublisher node
    try:
        rclpy.spin(node)                  # Keep the node running to handle callbacks
    except KeyboardInterrupt:
        pass                              # Allow clean shutdown on Ctrl+C
    finally:
        node.destroy_node()               # Destroy the node and free its resources
        rclpy.shutdown()                  # Shutdown the ROS 2 system

# Entry point of the script
if __name__ == '__main__':
    main()                                # Execute the main function
