import rclpy                               # Import the ROS 2 Python client library
from rclpy.node import Node                # Import the Node class to create ROS 2 nodes
from std_msgs.msg import String            # Import the standard String message type

# Define a class that subscribes to a topic and processes incoming messages
class CommandSubscriber(Node):
    def __init__(self):
        super().__init__('command_subscriber')  # Initialize the node with the name 'command_subscriber'
        
        # Create a subscriber to listen to messages on the '/robot/command' topic
        self.subscriber_ = self.create_subscription(
            String,                           # Message type expected on the topic
            '/robot/command',                 # Topic name to subscribe to
            self.command_callback,            # Callback function to handle received messages
            10                                # Queue size for storing incoming messages
        )

        # Log an informational message indicating that the node has started
        self.get_logger().info('Command Subscriber Node has been started')

    # Callback function executed whenever a new message is received on the subscribed topic
    def command_callback(self, msg):
        command = msg.data.lower()  # Convert the received string message to lowercase
        # Log the received command to the console
        self.get_logger().info(f'Received command: "{command}"')


# Main function that starts the ROS 2 node
def main(args=None):
    rclpy.init(args=args)                 # Initialize the ROS 2 Python library
    node = CommandSubscriber()            # Create an instance of the CommandSubscriber node
    try:
        rclpy.spin(node)                  # Keep the node running, waiting for messages
    except KeyboardInterrupt:
        pass                              # Allow graceful shutdown when Ctrl+C is pressed
    finally:
        node.destroy_node()               # Destroy the node and release its resources
        rclpy.shutdown()                  # Shutdown the ROS 2 system

# Entry point of the script
if __name__ == '__main__':
    main()                                # Run the main function
