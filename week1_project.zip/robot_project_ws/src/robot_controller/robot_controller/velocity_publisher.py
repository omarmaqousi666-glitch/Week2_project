import rclpy                                   # Import the ROS 2 Python client library
from rclpy.node import Node                    # Import the Node base class for creating ROS 2 nodes
from geometry_msgs.msg import Twist            # Import the Twist message type (used for linear and angular velocity)
from std_msgs.msg import String                # Import the standard String message type (for commands)

# Define a node class that publishes velocity commands based on received robot commands
class VelocityPublisher(Node):
    def __init__(self):
        super().__init__('velocity_publisher')     # Initialize the node with the name 'velocity_publisher'

        # Declare a parameter for controlling how often velocity messages are published (default = 1 second)
        self.declare_parameter('timer_period', 1)
        timer_period = self.get_parameter('timer_period').value  # Retrieve the parameter value

        # Create a publisher to send velocity commands on the '/cmd_vel' topic
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)

        # Create a Twist message for linear and angular velocity
        self.vel_msg = Twist()
        self.vel_msg.linear.x = 0.0        # Set initial linear velocity to 0
        self.vel_msg.angular.z = 0.0       # Set initial angular velocity to 0
        
        # Create a subscriber to listen for text commands on the '/robot/command' topic
        self.subscriber_ = self.create_subscription(
            String,                        # Message type
            '/robot/command',              # Topic name
            self.command_callback,         # Callback function to handle commands
            10                             # Queue size
        )
        
        # Create a timer to periodically call the 'publish_velocity' function
        self.timer_ = self.create_timer(timer_period, self.publish_velocity)
        
        # Log that the node has started and display the timer period
        self.get_logger().info(f'Velocity Publisher started with timer = {self.timer_}s')

    # Function that publishes the current velocity at regular intervals
    def publish_velocity(self):
        try:
            self.publisher_.publish(self.vel_msg)  # Publish the velocity message
            # Log the published velocity values
            self.get_logger().info(f'Published velocity: linear={self.vel_msg.linear.x}, angular={self.vel_msg.angular.z}')
        except Exception as e:
            # Log any publishing errors
            self.get_logger().error(f'Failed to publish velocity: {e}')

    # Callback function executed when a command message is received
    def command_callback(self, msg):
        # Check the received command and update the velocity accordingly
        if msg.data.lower() == 'start':
            self.vel_msg.linear.x = 3.0      # Move forward with linear velocity
            self.vel_msg.angular.z = 0.5     # Apply small rotation
        elif msg.data.lower() == 'stop':
            self.vel_msg.linear.x = 0.0      # Stop linear movement
            self.vel_msg.angular.z = 0.0     # Stop rotation
        elif msg.data.lower() == 'reset':
            self.vel_msg.linear.x = 0.0      # Reset to no movement
            self.vel_msg.angular.z = 0.0


# Main function that initializes and runs the node
def main(args=None):
    rclpy.init(args=args)                    # Initialize the ROS 2 Python client library
    node = VelocityPublisher()               # Create an instance of the VelocityPublisher node
    try:
        rclpy.spin(node)                     # Keep the node active and processing callbacks
    except KeyboardInterrupt:
        pass                                 # Gracefully handle Ctrl+C interruption
    finally:
        node.destroy_node()                  # Clean up the node before exiting
        rclpy.shutdown()                     # Shut down the ROS 2 system


# Entry point of the script
if __name__ == '__main__':
    main()                                   # Execute the main function
